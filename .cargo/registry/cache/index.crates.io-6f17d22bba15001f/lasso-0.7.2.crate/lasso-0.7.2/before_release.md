1. Update version of Cargo.toml
2. Remove `multi-threaded` feature default features
3. Update benchmarks
