# napi-derive-backend

Take care the ast parsing from `napi-derive` and generate "bridge" runtime code for both nodejs and rust.
